#!/bin/bash

rm EGauthorGuidelines-conf-fin.pdf
rm *.aux *.bbl *.blg *.brf *.lbl *.log *.synctex.gz
