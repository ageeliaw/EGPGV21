Necessary styles:
  -- ifpdf.sty
  -- cite.sty (not for usage with biblatex/biber)
  -- url.sty
  -- HYPERREF Package

You might visit the official sources at https://ctan.org/tex-archive

Please make sure your installation has the latest version of the
packages URL and HYPERREF.

BibLaTex with Biber is now possible, store EG.bbx in the LaTeX distribution, 
for TeXLive in Windows: C:\texlive\2018\texmf-dist\tex\latex\biblatex\bbx
and update filename database.
(as an example please compare file ...fin_with_teaser.tex where the settings 
are made for biblatex usage.)

For questions concerning the Eurographics Style please contact publishing@eg.org

